<a href="<?php echo home_url(); ?>">
    <img src="<?php echo get_template_directory_uri(); ?>/img/Tomoori_logo.png" alt="Logo" class="logo-img">
</a>
