<button class="responsive-menu-button responsive-menu-boring responsive-menu-accessible" type="button" aria-label="Menu">
    <span class="responsive-menu-box">
        <span class="responsive-menu-inner"></span>
    </span>
</button>